package com.example.elenna_delivery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
