class FoodEntity {
  String imageAsset;
  String nama;
  String harga;
  String rating;
  String deskripsi;

  FoodEntity(
      {required this.imageAsset,
      required this.nama,
      required this.harga,
      required this.rating,
      required this.deskripsi});
}
